# PhishGuard with Docker (free hosting)

## Run locally
```bash
docker compose up --build
# open http://localhost:8000
```
(or: `docker build -t phishguard .` then `docker run -p 8000:8000 phishguard`)

## Deploy free on Render (Docker, gives https://phishguard.onrender.com)
1. Push this folder to a GitHub repo.
2. https://render.com -> sign up with GitHub (free, no card for the free web service).
3. **New + -> Blueprint** -> pick the repo (it reads `render.yaml`)
   - or **New + -> Web Service** -> pick repo -> Runtime **Docker** -> Instance type **Free**.
4. Click Deploy. First build takes ~5 min. URL: `https://<name>.onrender.com`.
Free tier sleeps after ~15 min idle; the next visit takes ~30-60 s to wake.

## Alternative: Hugging Face Spaces (Docker, free, no card)
New Space -> SDK **Docker** -> push this folder; add `app_port: 8000` to the
README.md front-matter. URL: `https://<user>-<space>.hf.space`.

## About the vercel.app domain
Vercel cannot run Docker containers, so a Docker deploy gets the host's own free domain
(onrender.com / hf.space). If you specifically want `*.vercel.app`, use the Vercel
setup from the first package (DEPLOY.md) - it needs no Docker.
